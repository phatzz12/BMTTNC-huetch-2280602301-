<?php include 'app/views/shares/header.php'; ?>
<div class="container d-flex flex-column align-items-center justify-content-center vh-100">
    <div class="text-center shadow-lg p-5 bg-white rounded">
        <h1 class="text-success fw-bold"><i class="fas fa-check-circle"></i> Xác nhận đơn hàng</h1>
        <p class="lead mt-3">🎉 Cảm ơn bạn đã đặt hàng! Đơn hàng của bạn đã được xử lý thành công. 🎉</p>
        <a href="/webbanhang/home" class="btn btn-primary mt-4 px-4 py-2 fw-bold">
            <i class="fas fa-shopping-bag"></i> Tiếp tục mua sắm
        </a>
    </div>
</div>
<?php include 'app/views/shares/footer.php'; ?>
