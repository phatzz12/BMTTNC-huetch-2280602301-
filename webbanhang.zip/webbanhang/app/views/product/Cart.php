<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id'], $_POST['action'])) {
    $id = $_POST['id'];

    if (isset($_SESSION['cart'][$id])) {
        if ($_POST['action'] === "increase") {
            $_SESSION['cart'][$id]['quantity']++;
        } elseif ($_POST['action'] === "decrease") {
            $_SESSION['cart'][$id]['quantity']--;
            if ($_SESSION['cart'][$id]['quantity'] <= 0) {
                unset($_SESSION['cart'][$id]); // Xóa sản phẩm nếu số lượng <= 0
            }
        }
    }
}

header("Location: /webbanhang/Product/checkout"); // Quay lại trang thanh toán
exit();
