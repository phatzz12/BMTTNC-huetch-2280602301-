<?php include 'app/views/shares/header.php'; ?>

<div class="container mt-5">
    <h2 class="text-center text-primary"><i class="fas fa-shopping-cart"></i> Thanh toán</h2>

    <?php $totalPrice = 0; ?>

    <?php if (isset($errorMessage)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <?php if (isset($successMessage)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($successMessage); ?></div>
    <?php endif; ?>

    <?php if (!empty($_SESSION['cart'])): ?>
        <div class="card shadow-sm">
            <div class="card-body">
                <table class="table table-bordered text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Tổng</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['cart'] as $id => $item): 
                            $subtotal = $item['price'] * $item['quantity'];
                            $totalPrice += $subtotal;
                        ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td><?php echo number_format($item['price'], 0, ',', '.'); ?> VND</td>
                            <td>
                                <form method="POST" action="/webbanhang/Product/updateCart" class="d-inline">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                    <button type="submit" name="action" value="decrease" class="btn btn-sm btn-danger"><i class="fas fa-minus"></i></button>
                                    <span class="mx-2"><?php echo $item['quantity']; ?></span>
                                    <button type="submit" name="action" value="increase" class="btn btn-sm btn-success"><i class="fas fa-plus"></i></button>
                                </form>
                            </td>
                            <td><strong><?php echo number_format($subtotal, 0, ',', '.'); ?> VND</strong></td>
                            <td>
                                <a href="/webbanhang/Product/removeFromCart?id=<?php echo $id; ?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="alert alert-info text-center">
                    <h4><strong>Tổng tiền: <?php echo number_format($totalPrice, 0, ',', '.'); ?> VND</strong></h4>
                </div>
            </div>
        </div>

        <!-- Form nhập thông tin khách hàng -->
        <div class="card mt-4 shadow-sm">
            <div class="card-body">
                <h4 class="text-center text-secondary"><i class="fas fa-user"></i> Thông tin khách hàng</h4>

                <form method="POST" action="/webbanhang/Product/processCheckout">
                    <input type="hidden" name="totalPrice" value="<?php echo $totalPrice; ?>">

                    <div class="mb-3">
                        <label for="name" class="form-label">Họ tên:</label>
                        <input type="text" id="name" name="name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label">Số điện thoại:</label>
                        <input type="tel" id="phone" name="phone" class="form-control" required pattern="[0-9]{10,15}">
                    </div>

                    <div class="mb-3">
                        <label for="address" class="form-label">Địa chỉ:</label>
                        <textarea id="address" name="address" class="form-control" required></textarea>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-credit-card"></i> Thanh toán</button>
                    </div>
                </form>
            </div>
        </div>

    <?php else: ?>
        <div class="alert alert-warning text-center">🛒 Giỏ hàng của bạn đang trống.</div>
    <?php endif; ?>

    <div class="text-center mt-3">
        <a href="/webbanhang/Product/cart" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Quay lại giỏ hàng</a>
    </div>
</div>

<?php include 'app/views/shares/footer.php'; ?>
