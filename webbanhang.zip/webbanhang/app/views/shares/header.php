<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('https://source.unsplash.com/1920x1080/?technology,machinery') no-repeat center center fixed;
            background-size: cover;
        }

        .navbar-custom {
            background: linear-gradient(45deg, #8B0000, #000000);
            background-size: 400% 400%;
            animation: gradientBG 8s ease infinite;
            padding: 15px 0;
        }

        @keyframes gradientBG {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .navbar-brand {
            font-size: 2rem;
            font-weight: bold;
            color: white !important;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);
        }

        .navbar-nav {
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .navbar-nav .nav-item {
            text-align: center;
            flex-grow: 1;
        }

        .navbar-nav .nav-link {
            font-size: 1.2rem;
            color: white !important;
            transition: 0.3s;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .navbar-nav .nav-link:hover, 
        .navbar-nav .nav-link.active {
            color: #ff0000 !important;
            text-shadow: 0 0 8px #ff0000, 0 0 12px #ff0000;
        }

        .content-box {
            background: rgba(255, 255, 255, 0.85);
            border-radius: 15px;
            padding: 25px;
            margin-top: 50px;
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
    </style>
</head>
<body>
    <?php $current_page = $_SERVER['REQUEST_URI']; ?>

    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand" href="/webbanhang/">⚙️ Store Không Bán Bẩn 🔥</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" 
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == '/webbanhang/' ? 'active' : ''); ?>" 
                           href="/webbanhang/">🏠 Trang chủ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo (strpos($current_page, '/Product/') !== false ? 'active' : ''); ?>" 
                           href="/webbanhang/Product/">📦 Danh sách sản phẩm</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_page == '/webbanhang/Product/add' ? 'active' : ''); ?>" 
                           href="/webbanhang/Product/add">➕ Thêm sản phẩm</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 pt-5">
        <div class="content-box">
            <h2 class="text-danger">🌟 Chào mừng đến với Store của KyFKyF 🌟</h2>
            <p>Nơi bạn có thể tìm thấy bất cứ thứ gì, nhanh chóng và dễ dàng.</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
