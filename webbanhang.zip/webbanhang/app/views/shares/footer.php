<footer class="text-center text-lg-start mt-4 text-white" style="background: linear-gradient(135deg, #1e3c72, #2a5298);">
    <div class="container p-4">
        <div class="row">
            <!-- Cột thông tin liên hệ -->
            <div class="col-lg-6 col-md-12 mb-4">
                <h5 class="text-uppercase fw-bold">⚙️ Quản lý sản phẩm</h5>
                <p class="opacity-75">
                    Hệ thống quản lý sản phẩm giúp bạn theo dõi và cập nhật thông tin sản phẩm dễ dàng.
                </p>
            </div>

            <!-- Cột liên kết nhanh -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-uppercase fw-bold">🚀 Liên kết nhanh</h5>
                <ul class="list-unstyled">
                    <li><a href="/webbanhang/Product/" class="text-white text-decoration-none d-block py-1">📦 Danh sách sản phẩm</a></li>
                    <li><a href="/webbanhang/Product/add" class="text-white text-decoration-none d-block py-1">➕ Thêm sản phẩm</a></li>
                </ul>
            </div>

            <!-- Cột mạng xã hội -->
            <div class="col-lg-3 col-md-6 mb-4">
                <h5 class="text-uppercase fw-bold">🌐 Kết nối với chúng tôi</h5>
                <div class="d-flex justify-content-center">
                    <a href="https://facebook.com" target="_blank" class="social-icon me-3">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com" target="_blank" class="social-icon me-3">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="https://instagram.com" target="_blank" class="social-icon">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Dòng bản quyền -->
    <div class="text-center p-3" style="background: rgba(0, 0, 0, 0.2);">
        © <?php echo date("Y"); ?> Quản lý sản phẩm. All rights reserved.
    </div>
</footer>

<!-- Font Awesome Icons (v6) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/js/all.min.js" crossorigin="anonymous"></script>

<style>
    /* Hiệu ứng hover cho link */
    footer a:hover {
        text-decoration: underline;
        color: #ffc107 !important;
    }

    /* Icon mạng xã hội */
    .social-icon {
        font-size: 1.5rem;
        color: white;
        transition: 0.3s;
    }

    .social-icon:hover {
        color: #ffc107;
        transform: scale(1.1);
    }
</style>
