<?php
// Require database and models
require_once('app/config/database.php');
require_once('app/models/CategoryModel.php');

class CategoryController {
    private $categoryModel;
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
        $this->categoryModel = new CategoryModel($this->db);
    }

    // Hiển thị danh sách danh mục
    public function list() {
        $categories = $this->categoryModel->getCategories();
        include 'app/views/category/list.php';
    }

    // Hiển thị form thêm danh mục
    public function add() {
        include 'app/views/category/add.php';
    }

    // Lưu danh mục mới
    public function save() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';

            if (!empty($name)) {
                $result = $this->categoryModel->addCategory($name, $description);
                if ($result) {
                    header('Location: /webbanhang/Category/list');
                    exit;
                } else {
                    echo "Đã xảy ra lỗi khi thêm danh mục.";
                }
            } else {
                echo "Tên danh mục không được để trống.";
            }
        }
    }

    // Hiển thị form chỉnh sửa danh mục
    public function edit($id) {
        $category = $this->categoryModel->getCategoryById($id);
        if ($category) {
            include 'app/views/category/edit.php';
        } else {
            echo "Không tìm thấy danh mục.";
        }
    }

    // Cập nhật danh mục
    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? null;
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';

            if ($id && !empty($name)) {
                $update = $this->categoryModel->updateCategory($id, $name, $description);
                if ($update) {
                    header('Location: /webbanhang/Category/list');
                    exit;
                } else {
                    echo "Đã xảy ra lỗi khi cập nhật danh mục.";
                }
            } else {
                echo "ID hoặc tên danh mục không hợp lệ.";
            }
        }
    }

    // Xóa danh mục
    public function delete($id) {
        if ($this->categoryModel->deleteCategory($id)) {
            header('Location: /webbanhang/Category/list');
            exit;
        } else {
            echo "Đã xảy ra lỗi khi xóa danh mục.";
        }
    }
}
?>
