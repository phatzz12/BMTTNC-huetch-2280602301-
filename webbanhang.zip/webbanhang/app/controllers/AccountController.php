<?php
require_once('app/config/database.php');
require_once('app/models/AccountModel.php');

session_start(); // 🔥 Bổ sung session_start()

class AccountController {
    private $accountModel;
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
        $this->accountModel = new AccountModel($this->db);
    }

    // 📌 Hiển thị trang đăng ký
    public function register() {
        include_once 'app/views/account/register.php';
    }

    // 📌 Hiển thị trang đăng nhập
    public function login() {
        include_once 'app/views/account/login.php';
    }

    // 📌 Xử lý đăng ký tài khoản
    public function save() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $fullName = $_POST['fullname'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirmPassword = $_POST['confirmpassword'] ?? '';
            $errors = [];

            // 🛑 Kiểm tra dữ liệu đầu vào
            if (empty($username)) $errors['username'] = "Vui lòng nhập Username!";
            if (empty($fullName)) $errors['fullname'] = "Vui lòng nhập Họ và Tên!";
            if (empty($password)) $errors['password'] = "Vui lòng nhập Mật khẩu!";
            if ($password !== $confirmPassword) $errors['confirmPass'] = "Mật khẩu và xác nhận chưa đúng!";

            // 🔍 Kiểm tra tài khoản đã tồn tại chưa?
            if ($this->accountModel->getAccountByUsername($username)) {
                $errors['account'] = "Tài khoản này đã có người đăng ký!";
            }

            // 🚨 Nếu có lỗi, quay lại form đăng ký
            if (!empty($errors)) {
                include_once 'app/views/account/register.php';
                return;
            }

            // 🔐 Mã hóa mật khẩu trước khi lưu
            $hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            // 📌 Thực hiện lưu tài khoản
            $result = $this->accountModel->save($username, $fullName, $hashed_password);
            if ($result) {
                header('Location: /webbanhang/account/login');
                exit;
            } else {
                echo "Lỗi: Không thể tạo tài khoản!";
            }
        }
    }

    // 📌 Xử lý đăng xuất
    public function logout() {
        session_destroy(); // 🔥 Xóa toàn bộ session
        header('Location: /webbanhang/product');
        exit;
    }

    // 📌 Xử lý đăng nhập
    public function checkLogin() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';

            $account = $this->accountModel->getAccountByUsername($username);
            if ($account) {
                // 🔑 Kiểm tra mật khẩu
                if (password_verify($password, $account->password)) {
         
